(function(window, undefined) {
  var dictionary = {
    "b24649bc-e483-48f4-9451-2edd372c5dc1": "scholoships",
    "55639bba-f6f2-4592-93c6-38bfee25825a": "map",
    "5640cb03-b654-4312-912b-55b4ac85744e": "url",
    "6ee6b4a2-bfed-4be2-83b9-2e92729a4253": "scholorship search",
    "e2fc4b40-0861-4025-8fa4-c7ff6c6eedb4": "info collage",
    "b0143b5d-7e06-47cc-bff7-f10042a9da13": "sign in",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Screen 1",
    "d1f4d321-2e32-48db-9e1f-5bb6dde6b788": "scholorship info",
    "38c14c33-85d0-4166-a948-36d4710b2cf3": "colage uni info",
    "2bed1a6e-34f3-44bc-8c77-968fa1aad6c5": "info collage 2",
    "335c2742-2bdb-4ad5-aff1-6c40002d4fca": "admison1",
    "4ecc7ad4-0a03-43b0-b6a4-a9a1fce1a48f": "admisions",
    "11cfc6bc-f6b3-46ff-9dbb-4de17d8e88cc": "discussion",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);