(function(window, undefined) {

  var jimLinks = {
    "b24649bc-e483-48f4-9451-2edd372c5dc1" : {
      "Input_2" : [
        "6ee6b4a2-bfed-4be2-83b9-2e92729a4253"
      ],
      "Button_1" : [
        "d1f4d321-2e32-48db-9e1f-5bb6dde6b788"
      ],
      "Button_2" : [
        "d1f4d321-2e32-48db-9e1f-5bb6dde6b788",
        "d1f4d321-2e32-48db-9e1f-5bb6dde6b788",
        "d1f4d321-2e32-48db-9e1f-5bb6dde6b788"
      ],
      "Button_3" : [
        "d1f4d321-2e32-48db-9e1f-5bb6dde6b788",
        "d1f4d321-2e32-48db-9e1f-5bb6dde6b788"
      ],
      "Button_4" : [
        "d1f4d321-2e32-48db-9e1f-5bb6dde6b788"
      ],
      "Button_5" : [
        "b0143b5d-7e06-47cc-bff7-f10042a9da13"
      ]
    },
    "55639bba-f6f2-4592-93c6-38bfee25825a" : {
      "Button_5" : [
        "38c14c33-85d0-4166-a948-36d4710b2cf3"
      ]
    },
    "5640cb03-b654-4312-912b-55b4ac85744e" : {
      "Button_5" : [
        "38c14c33-85d0-4166-a948-36d4710b2cf3"
      ]
    },
    "6ee6b4a2-bfed-4be2-83b9-2e92729a4253" : {
      "Button_5" : [
        "b24649bc-e483-48f4-9451-2edd372c5dc1"
      ]
    },
    "e2fc4b40-0861-4025-8fa4-c7ff6c6eedb4" : {
      "Input_2" : [
        "6ee6b4a2-bfed-4be2-83b9-2e92729a4253"
      ],
      "Button_5" : [
        "b0143b5d-7e06-47cc-bff7-f10042a9da13"
      ]
    },
    "b0143b5d-7e06-47cc-bff7-f10042a9da13" : {
      "Button_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_4" : [
        "b24649bc-e483-48f4-9451-2edd372c5dc1"
      ],
      "Text_5" : [
        "4ecc7ad4-0a03-43b0-b6a4-a9a1fce1a48f"
      ],
      "Text_6" : [
        "11cfc6bc-f6b3-46ff-9dbb-4de17d8e88cc"
      ],
      "Text_7" : [
        "38c14c33-85d0-4166-a948-36d4710b2cf3"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Button_1" : [
        "b0143b5d-7e06-47cc-bff7-f10042a9da13"
      ],
      "Button_2" : [
        "b0143b5d-7e06-47cc-bff7-f10042a9da13"
      ]
    },
    "d1f4d321-2e32-48db-9e1f-5bb6dde6b788" : {
      "Button_5" : [
        "b24649bc-e483-48f4-9451-2edd372c5dc1"
      ]
    },
    "38c14c33-85d0-4166-a948-36d4710b2cf3" : {
      "Button_5" : [
        "4ecc7ad4-0a03-43b0-b6a4-a9a1fce1a48f"
      ],
      "Button_1" : [
        "2bed1a6e-34f3-44bc-8c77-968fa1aad6c5"
      ]
    },
    "2bed1a6e-34f3-44bc-8c77-968fa1aad6c5" : {
      "Button_5" : [
        "4ecc7ad4-0a03-43b0-b6a4-a9a1fce1a48f",
        "38c14c33-85d0-4166-a948-36d4710b2cf3"
      ],
      "Button_1" : [
        "5640cb03-b654-4312-912b-55b4ac85744e"
      ],
      "Button_2" : [
        "55639bba-f6f2-4592-93c6-38bfee25825a"
      ]
    },
    "335c2742-2bdb-4ad5-aff1-6c40002d4fca" : {
      "Button_5" : [
        "4ecc7ad4-0a03-43b0-b6a4-a9a1fce1a48f"
      ],
      "Button_1" : [
        "e2fc4b40-0861-4025-8fa4-c7ff6c6eedb4"
      ],
      "Button_2" : [
        "e2fc4b40-0861-4025-8fa4-c7ff6c6eedb4"
      ],
      "Button_3" : [
        "e2fc4b40-0861-4025-8fa4-c7ff6c6eedb4"
      ]
    },
    "4ecc7ad4-0a03-43b0-b6a4-a9a1fce1a48f" : {
      "Button_5" : [
        "b0143b5d-7e06-47cc-bff7-f10042a9da13"
      ],
      "Button_1" : [
        "335c2742-2bdb-4ad5-aff1-6c40002d4fca"
      ],
      "Button_2" : [
        "335c2742-2bdb-4ad5-aff1-6c40002d4fca"
      ],
      "Button_3" : [
        "335c2742-2bdb-4ad5-aff1-6c40002d4fca"
      ],
      "Button_4" : [
        "335c2742-2bdb-4ad5-aff1-6c40002d4fca"
      ],
      "Button_6" : [
        "335c2742-2bdb-4ad5-aff1-6c40002d4fca"
      ],
      "Button_7" : [
        "335c2742-2bdb-4ad5-aff1-6c40002d4fca"
      ]
    },
    "11cfc6bc-f6b3-46ff-9dbb-4de17d8e88cc" : {
      "Input_2" : [
        "6ee6b4a2-bfed-4be2-83b9-2e92729a4253"
      ],
      "Button_5" : [
        "b0143b5d-7e06-47cc-bff7-f10042a9da13"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);