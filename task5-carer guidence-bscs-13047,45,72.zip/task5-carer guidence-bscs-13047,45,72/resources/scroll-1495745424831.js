(function(window, undefined) {

    /*********************** START STATIC ACCESS METHODS ************************/

    jQuery.extend(jimMobile, {
        "loadScrollBars": function() {
            jQuery(".s-b24649bc-e483-48f4-9451-2edd372c5dc1 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-55639bba-f6f2-4592-93c6-38bfee25825a .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-5640cb03-b654-4312-912b-55b4ac85744e .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-6ee6b4a2-bfed-4be2-83b9-2e92729a4253 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-e2fc4b40-0861-4025-8fa4-c7ff6c6eedb4 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-b0143b5d-7e06-47cc-bff7-f10042a9da13 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-d1f4d321-2e32-48db-9e1f-5bb6dde6b788 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-38c14c33-85d0-4166-a948-36d4710b2cf3 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-2bed1a6e-34f3-44bc-8c77-968fa1aad6c5 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-335c2742-2bdb-4ad5-aff1-6c40002d4fca .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-4ecc7ad4-0a03-43b0-b6a4-a9a1fce1a48f .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-11cfc6bc-f6b3-46ff-9dbb-4de17d8e88cc .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
         }
    });

    /*********************** END STATIC ACCESS METHODS ************************/

}) (window);